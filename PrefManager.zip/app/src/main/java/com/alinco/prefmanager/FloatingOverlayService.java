package com.alinco.prefmanager;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.Choreographer;
import android.widget.TextView;
import android.os.BatteryManager;
import android.content.IntentFilter;

public class FloatingOverlayService extends Service {

    private WindowManager windowManager;
    private View overlayView;
    private TextView tvFps, tvRam, tvTemp, tvOnlineHud;
    
    private Choreographer choreographer;
    private long lastFrameTimeNanos = 0;
    private Handler fpsHandler;
    private Runnable fpsRunnable;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        overlayView = inflater.inflate(R.layout.overlay_layout, null);

        tvFps = overlayView.findViewById(R.id.tvFps);
        tvRam = overlayView.findViewById(R.id.tvRam);
        tvTemp = overlayView.findViewById(R.id.tvTemp);
        tvOnlineHud = overlayView.findViewById(R.id.tvOnlineHud);

        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 100;

        // Make overlay draggable
        overlayView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(overlayView, params);
                        return true;
                }
                return false;
            }
        });

        windowManager.addView(overlayView, params);

        // Start FPS tracking via Choreographer
        startFpsTracking();
    }

    private void startFpsTracking() {
        fpsHandler = new Handler(Looper.getMainLooper());
        choreographer = Choreographer.getInstance();

        Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (lastFrameTimeNanos != 0) {
                    long diff = frameTimeNanos - lastFrameTimeNanos;
                    double fps = 1000000000.0 / diff;
                    if (tvFps != null) {
                        tvFps.setText("FPS: " + (int) fps);
                    }
                }
                lastFrameTimeNanos = frameTimeNanos;
                if (choreographer != null) {
                    choreographer.postFrameCallback(this);
                }
            }
        };
        choreographer.postFrameCallback(frameCallback);

        // Periodically update RAM and Battery Temp
        fpsRunnable = new Runnable() {
            @Override
            public void run() {
                updateSystemStats();
                fpsHandler.postDelayed(this, 1000);
            }
        };
        fpsHandler.post(fpsRunnable);
    }

    private void updateSystemStats() {
        // RAM usage approximation
        Runtime runtime = Runtime.getRuntime();
        long usedMem = (runtime.totalMemory() - runtime.freeMemory()) / 1048576L;
        long totalMem = runtime.maxMemory() / 1048576L;
        int ramPercent = (int) ((double) usedMem / totalMem * 100);
        if (tvRam != null) {
            tvRam.setText("RAM: " + ramPercent + "%");
        }

        // Battery / Thermal status check
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);
            if (batteryStatus != null) {
                int temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
                float tempC = temp / 10.0f;
                if (tvTemp != null) {
                    tvTemp.setText("Temp: " + tempC + "°C");
                }
            }
        } catch (Exception e) {
            if (tvTemp != null) {
                tvTemp.setText("Temp: Normal");
            }
        }

        // Update online user count text on HUD
        if (tvOnlineHud != null) {
            tvOnlineHud.setText("Online: Active");
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (fpsHandler != null && fpsRunnable != null) {
            fpsHandler.removeCallbacks(fpsRunnable);
        }
        if (overlayView != null) {
            windowManager.removeView(overlayView);
        }
    }
}
