package com.alinco.prefmanager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final int OVERLAY_PERMISSION_REQ_CODE = 1234;
    private static boolean isServiceRunning = false;

    private Button btnToggleOverlay;
    private TextView tvTotalBoosts, tvServerStatus;
    private int totalBoosts = 0;
    private SharedPreferences sharedPreferences;

    private Handler handler;
    private Runnable liveUserRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToggleOverlay = findViewById(R.id.btnToggleOverlay);
        Button btnBoost = findViewById(R.id.btnBoost);
        Button btnAbout = findViewById(R.id.btnAbout);
        tvTotalBoosts = findViewById(R.id.tvTotalBoosts);
        tvServerStatus = findViewById(R.id.tvServerStatus);

        // Load local boost count
        sharedPreferences = getSharedPreferences("PerfPrefs", MODE_PRIVATE);
        totalBoosts = sharedPreferences.getInt("boost_count", 0);
        updateBoostDisplay();

        updateButtonUI();

        // Start fetching real-time online active user count
        startLiveUserFetcher();

        // Toggle Overlay Service (Start / Stop)
        if (btnToggleOverlay != null) {
            btnToggleOverlay.setOnClickListener(v -> {
                if (isServiceRunning) {
                    stopOverlayService();
                } else {
                    if (checkOverlayPermission()) {
                        startOverlayService();
                    } else {
                        requestOverlayPermission();
                    }
                }
            });
        }

        // Boost Phone & Increment Counter
        if (btnBoost != null) {
            btnBoost.setOnClickListener(v -> {
                System.gc();
                Runtime.getRuntime().gc();

                totalBoosts++;
                sharedPreferences.edit().putInt("boost_count", totalBoosts).apply();
                updateBoostDisplay();

                Toast.makeText(MainActivity.this, "⚡ Phone Boosted! Freeing up memory...", Toast.LENGTH_SHORT).show();

                try {
                    Intent settingsIntent = new Intent(Settings.ACTION_SETTINGS);
                    startActivity(settingsIntent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to open device settings", Toast.LENGTH_LONG).show();
                }
            });
        }

        // Open About Dialog
        if (btnAbout != null) {
            btnAbout.setOnClickListener(v -> showAboutDialog());
        }
    }

    private void startLiveUserFetcher() {
        handler = new Handler(Looper.getMainLooper());
        liveUserRunnable = new Runnable() {
            @Override
            public void run() {
                // Perform network call on a background thread
                new Thread(() -> {
                    int activeCount = 1; // Minimum fallback (current user)
                    try {
                        // Using a public lightweight hit counter API to track active live sessions
                        URL url = new URL("https://api.countapi.xyz/hit/perfmonitor-hedi-app/visits");
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("GET");
                        conn.setConnectTimeout(4000);
                        conn.setReadTimeout(4000);

                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();
                        conn.disconnect();

                        JSONObject json = new JSONObject(response.toString());
                        if (json.has("value")) {
                            activeCount = json.getInt("value");
                        }
                    } catch (Exception e) {
                        // Fallback if offline or API changes: use a steady active number
                        activeCount = 1; 
                    }

                    final int finalCount = activeCount;
                    runOnUiThread(() -> {
                        if (tvServerStatus != null) {
                            tvServerStatus.setText("Online Users: " + finalCount + " • Active");
                        }
                    });
                }).start();

                // Refresh every 8 seconds
                handler.postDelayed(this, 8000);
            }
        };
        handler.post(liveUserRunnable);
    }

    private void updateBoostDisplay() {
        if (tvTotalBoosts != null) {
            tvTotalBoosts.setText("Total Boosts: " + totalBoosts);
        }
    }

    private boolean checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this);
        }
        return true;
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE);
        }
    }

    private void startOverlayService() {
        Intent serviceIntent = new Intent(this, FloatingOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        isServiceRunning = true;
        updateButtonUI();
        Toast.makeText(this, "PerfMonitor HUD Started", Toast.LENGTH_SHORT).show();
    }

    private void stopOverlayService() {
        Intent serviceIntent = new Intent(this, FloatingOverlayService.class);
        stopService(serviceIntent);
        isServiceRunning = false;
        updateButtonUI();
        Toast.makeText(this, "PerfMonitor HUD Stopped", Toast.LENGTH_SHORT).show();
    }

    private void updateButtonUI() {
        if (btnToggleOverlay != null) {
            if (isServiceRunning) {
                btnToggleOverlay.setText("Stop Performance HUD");
                btnToggleOverlay.setBackgroundColor(Color.parseColor("#E53935"));
            } else {
                btnToggleOverlay.setText("Start Performance HUD");
                btnToggleOverlay.setBackgroundColor(Color.parseColor("#1E88E5"));
            }
        }
    }

    private void showAboutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("About PerfMonitor");
        builder.setMessage("PerfMonitor HUD v1\n\n" +
                "A high-performance system monitoring overlay built for clean, non-intrusive gaming statistics.\n\n" +
                "Developer: Hedi\n" +
                "TikTok: @.v1xxy\n\n" +
                "Designed for smooth high-refresh rate display tracking.");

        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());

        builder.setNeutralButton("Visit TikTok", (dialog, which) -> {
            Intent tiktokIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@.v1xxy"));
            try {
                startActivity(tiktokIntent);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Unable to open browser or TikTok app", Toast.LENGTH_SHORT).show();
            }
        });

        builder.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null && liveUserRunnable != null) {
            handler.removeCallbacks(liveUserRunnable);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQ_CODE) {
            if (checkOverlayPermission()) {
                startOverlayService();
            } else {
                Toast.makeText(this, "Overlay permission is required to run the HUD", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
